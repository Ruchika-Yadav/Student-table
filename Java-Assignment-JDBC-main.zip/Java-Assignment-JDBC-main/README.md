# Java-Assignment-JDBC
CRUD Operations 

Develop a simple Java program to implement the CRUD  i.e create / read /update / delete students data from Student table.
This java program should do the following.
1. Insert student data into Student table
2. Update student data into Student table
3. Delete student data from Student table
4. Get a list of all students
5. Get one student information depending on the student id filter.
